"""
Functions for generating MongoDB insert mutation files.
"""
import os
from typing import Dict, Any, List

from scripts.mongo_mutations.utils.file_utils import save_json_file


def generate_insert_arguments(fields: Dict[str, Any]) -> Dict[str, Any]:
    """
    Generate arguments for an insert mutation based on collection fields.
    
    Args:
        fields: Fields dictionary from schema
        
    Returns:
        Dictionary of arguments for the mutation
    """
    arguments = {}
    
    for field_name, field_info in fields.items():
        # Skip _id field for insert mutations
        if field_name == "_id":
            continue
            
        # Extract the complete type information
        type_info = field_info["type"]
        arguments[_camel_to_lower(field_name)] = {
            "type": _extract_type_info(type_info)
        }
    
    return arguments


def _extract_type_info(type_info: Dict[str, Any]) -> Dict[str, Any]:
    """
    Extract the complete type information from a type dictionary.
    
    Args:
        type_info: Type information dictionary
        
    Returns:
        Complete type information as a dictionary
    """
    # Direct scalar type
    if "scalar" in type_info:
        return {"scalar": type_info["scalar"]}
    
    # Object type
    elif "object" in type_info:
        return {"object": type_info["object"]}
    
    # Array type
    elif "arrayOf" in type_info:
        return {"arrayOf": type_info["arrayOf"]}
    
    # Nullable wrapper
    elif "nullable" in type_info:
        if isinstance(type_info["nullable"], dict):
            return {"nullable": _extract_type_info(type_info["nullable"])}
        else:
            return {"nullable": type_info["nullable"]}
            
    # ExtendedJSON or other types
    elif "extendedJSON" in type_info:
        return {"extendedJSON": True}
        
    return {}


def _extract_scalar_type(type_info: Dict[str, Any]) -> str:
    """
    Extract the scalar type from a type dictionary.
    
    Args:
        type_info: Type information dictionary
        
    Returns:
        Scalar type as a string, or None if not a scalar type
    """
    extracted = _extract_type_info(type_info)
    if "scalar" in extracted:
        return extracted["scalar"]
    elif "nullable" in extracted and isinstance(extracted["nullable"], dict):
        if "scalar" in extracted["nullable"]:
            return extracted["nullable"]["scalar"]
    
    return None


def _camel_to_lower(s: str) -> str:
    """
    Convert a CamelCase string to lowercase.
    
    Args:
        s: CamelCase string
        
    Returns:
        Lowercase string
    """
    return s[0].lower() + s[1:]


def generate_document_template(fields: Dict[str, Any]) -> Dict[str, str]:
    """
    Generate a document template for an insert mutation.
    
    Args:
        fields: Fields dictionary from schema
        
    Returns:
        Dictionary with field names and template variables
    """
    document = {}
    
    for field_name, field_info in fields.items():
        # Skip _id field for insert mutations
        if field_name == "_id":
            continue
            
        # Create template variable
        var_name = _camel_to_lower(field_name)
        document[field_name] = f"{{{{ {var_name} }}}}"
    
    return document


def generate_insert_mutation(collection_info: Dict[str, Any], output_dir: str) -> str:
    """
    Generate an insert mutation file.
    
    Args:
        collection_info: Collection information dictionary
        output_dir: Directory to save the mutation file
        
    Returns:
        Path to the generated file
    """
    collection_name = collection_info["collection_name"]
    object_type = collection_info["object_type"]
    fields = collection_info["fields"]
    
    # Create a result type name
    result_type_name = f"Insert{collection_name}"
    
    # Generate arguments from fields (excluding _id)
    arguments = generate_insert_arguments(fields)
    
    # Generate document template
    document = generate_document_template(fields)
    
    # Create the mutation
    mutation = {
        "name": f"insert{collection_name}",
        "description": f"Insert a new {collection_name} document",
        "resultType": {
            "object": result_type_name
        },
        "arguments": arguments,
        "objectTypes": {
            result_type_name: {
                "fields": {
                    "ok": {
                        "type": {
                            "scalar": "int"
                        }
                    },
                    "value": {
                        "type": {
                            "object": collection_name
                        }
                    }
                }
            }
        },
        "command": {
            "findAndModify": collection_name,
            "query": { "_id": { "$exists": False } },
            "update": [{
                "$set": {
                    **document
                }
            }],
            "upsert": True,
            "new": True
        }
    }
    
    filepath = os.path.join(output_dir, f"insert_{collection_name.lower()}.json")
    save_json_file(filepath, mutation)
    return filepath
