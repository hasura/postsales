"""
MongoDB Mutation Generator Package

This package provides tools for generating MongoDB mutation files from schema definitions.
"""

__version__ = "0.1.0"
